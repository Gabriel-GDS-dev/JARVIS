# ============================================================
# interface/streamlit_app.py
# Interface web do Jarvis usando Streamlit
#
# Como rodar:
#   streamlit run interface/streamlit_app.py
# ============================================================

import streamlit as st
import requests

# ── Configuração da página ───────────────────────────────────
st.set_page_config(
    page_title="Jarvis AI",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# URL base da API FastAPI
API_URL = "http://localhost:8000"


# ── Funções auxiliares ───────────────────────────────────────

def check_api_status():
    """Verifica se a API está online."""
    try:
        response = requests.get(f"{API_URL}/status", timeout=3)
        return response.json()
    except Exception:
        return None


def send_message(message: str, conversation_id: int = None):
    """Envia mensagem para a API e retorna a resposta."""
    try:
        response = requests.post(
            f"{API_URL}/chat/",
            json={"message": message, "conversation_id": conversation_id},
            timeout=120,
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.ConnectionError:
        st.error("❌ API não está rodando. Execute: uvicorn app.main:app --reload")
        return None
    except Exception as e:
        st.error(f"Erro: {str(e)}")
        return None


def get_memories():
    """Busca todas as memórias salvas."""
    try:
        response = requests.get(f"{API_URL}/memory/", timeout=5)
        return response.json()
    except Exception:
        return []


def save_memory(content: str, memory_type: str):
    """Salva uma nova memória via API."""
    try:
        response = requests.post(
            f"{API_URL}/memory/",
            json={"content": content, "memory_type": memory_type, "relevance": 1.0},
            timeout=10,
        )
        return response.status_code == 201
    except Exception:
        return False


def delete_memory(memory_id: int):
    """Deleta uma memória pelo ID."""
    try:
        requests.delete(f"{API_URL}/memory/{memory_id}", timeout=5)
    except Exception:
        pass


def get_conversations():
    """Lista as conversas recentes."""
    try:
        response = requests.get(f"{API_URL}/chat/conversations", timeout=5)
        return response.json()
    except Exception:
        return []


# ── Inicializa o estado da sessão ────────────────────────────

if "messages" not in st.session_state:
    st.session_state.messages = []

if "conversation_id" not in st.session_state:
    st.session_state.conversation_id = None


# ── Sidebar ──────────────────────────────────────────────────

with st.sidebar:
    st.title("🤖 Jarvis AI")
    st.markdown("---")

    # Status do sistema
    st.subheader("📡 Status do Sistema")
    status = check_api_status()
    if status:
        st.success(f"API: ✅ Online")
        ollama_status = status.get("ollama", "desconhecido")
        if ollama_status == "ok":
            st.success(f"Ollama: ✅ Online")
            st.info(f"Modelo: `{status.get('model', '?')}`")
        else:
            st.error(f"Ollama: ❌ Offline")
            st.warning("Execute `ollama serve` no terminal")
    else:
        st.error("API: ❌ Offline")
        st.warning("Execute: `uvicorn app.main:app --reload`")

    st.markdown("---")

    # Nova conversa
    st.subheader("💬 Conversa")
    if st.button("🆕 Nova Conversa", use_container_width=True):
        st.session_state.messages = []
        st.session_state.conversation_id = None
        st.rerun()

    # Histórico de conversas
    conversations = get_conversations()
    if conversations:
        st.subheader("📜 Conversas Recentes")
        for conv in conversations[:5]:
            title = conv.get("title") or f"Conversa #{conv['id']}"
            if len(title) > 30:
                title = title[:30] + "..."
            if st.button(f"💬 {title}", key=f"conv_{conv['id']}", use_container_width=True):
                st.session_state.conversation_id = conv["id"]
                # Carrega mensagens da conversa selecionada
                try:
                    resp = requests.get(f"{API_URL}/chat/conversations/{conv['id']}/messages")
                    data = resp.json()
                    st.session_state.messages = [
                        {"role": m["role"], "content": m["content"]}
                        for m in data.get("messages", [])
                    ]
                    st.rerun()
                except Exception:
                    pass

    st.markdown("---")

    # Memórias
    st.subheader("🧠 Memórias")

    # Adicionar nova memória
    with st.expander("➕ Adicionar Memória"):
        mem_content = st.text_area("Conteúdo:", placeholder="Ex: Prefiro respostas curtas")
        mem_type = st.selectbox("Tipo:", ["fato", "preferencia", "tarefa", "nota"])
        if st.button("Salvar Memória"):
            if mem_content.strip():
                if save_memory(mem_content.strip(), mem_type):
                    st.success("✅ Memória salva!")
                    st.rerun()
                else:
                    st.error("Erro ao salvar memória.")
            else:
                st.warning("Digite o conteúdo da memória.")

    # Lista de memórias
    memories = get_memories()
    if memories:
        for mem in memories:
            with st.expander(f"[{mem['memory_type']}] {mem['content'][:40]}..."):
                st.write(mem["content"])
                st.caption(f"Relevância: {mem['relevance']} | ID: {mem['id']}")
                if st.button("🗑️ Deletar", key=f"del_mem_{mem['id']}"):
                    delete_memory(mem["id"])
                    st.rerun()
    else:
        st.info("Nenhuma memória salva ainda.")

    st.markdown("---")
    st.caption("Jarvis AI v1.0 — Local & Privado")


# ── Área principal de chat ───────────────────────────────────

st.title("💬 Converse com o Jarvis")

conv_label = f"Conversa #{st.session_state.conversation_id}" if st.session_state.conversation_id else "Nova Conversa"
st.caption(f"🗂️ {conv_label}")

# Exibe o histórico de mensagens
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Campo de entrada do usuário
if user_input := st.chat_input("Digite sua mensagem..."):

    # Exibe a mensagem do usuário imediatamente
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    # Envia para a API e exibe a resposta
    with st.chat_message("assistant"):
        with st.spinner("Jarvis está pensando..."):
            result = send_message(user_input, st.session_state.conversation_id)

        if result:
            reply = result["reply"]
            st.session_state.conversation_id = result["conversation_id"]
            st.session_state.messages.append({"role": "assistant", "content": reply})
            st.markdown(reply)
        else:
            st.error("Não foi possível obter uma resposta.")
